import os

print("API KEY:", os.getenv("OPENROUTER_API_KEY"))
print("MODEL:", os.getenv("OPENROUTER_MODEL"))
